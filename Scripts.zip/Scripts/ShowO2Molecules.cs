﻿using UnityEngine;
using VRStandardAssets.Utils;

public class ShowO2Molecules : MonoBehaviour {
	[SerializeField] private VRInteractiveItem O2Menu;
	public GameObject CH4;
	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
	
	}

	private void OnEnable(){
		O2Menu.OnClick += HandleClick;
	}

	private void OnDisable(){
		O2Menu.OnClick -= HandleClick;
	}

	private void HandleClick() {
		Debug.Log ("HandleClick()");
		CH4.SetActive (true);
	}
}
