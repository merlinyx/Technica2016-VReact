using UnityEngine;
using System.Collections;
using UnityEngine.UI;

public class InvisibleDefault : MonoBehaviour {
	public GameObject CO2;
	public GameObject CH4;
	public GameObject H2O_1;
	public GameObject HCl_1;
	public GameObject CH3OH;
	public GameObject H3O;
	public GameObject Cl;
	public GameObject CH4_info;
	public GameObject HCl_info;
	public GameObject H2O_info;
	public GameObject O2_info;

	// Use this for initialization
	void Start () {

		CO2.SetActive (false);
		CH4.SetActive (false);
		H2O_1.SetActive (false);
		HCl_1.SetActive (false);
		CH3OH.SetActive (false);
		H3O.SetActive (false);
		Cl.SetActive (false);
		CH4_info.SetActive (false);
		HCl_info.SetActive (false);
		H2O_info.SetActive (false);
		O2_info.SetActive (false);

	}
	
	// Update is called once per frame
	void Update () {
		
		/*if (GUI.Button (new Rect ())) {
			HCl_1.SetActive (true);
		}
		if (GUI.Button (new Rect ())) {
			CH3OH.SetActive (true);
		}
		if (GUI.Button (new Rect ())) {
			H3O.SetActive (true);
		}
		if (GUI.Button (new Rect ())) {
			Cl.SetActive (true);
		}*/

	}
}
