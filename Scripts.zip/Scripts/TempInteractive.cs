﻿using UnityEngine;
using VRStandardAssets.Utils;

public class TempInteractive : MonoBehaviour {

	[SerializeField] private VRInteractiveItem O2;

	public GameObject O2Menu;

	// Use this for initialization
	void Start () {
	}
	
	// Update is called once per frame
	void Update () {
	}

	private void OnEnable(){
		O2.OnClick += HandleClick;
	}

	private void OnDisable(){
		O2.OnClick -= HandleClick;
	}

	private void HandleClick() {
		Debug.Log ("HandleClick()");
		O2Menu.SetActive (true);
	}
}
